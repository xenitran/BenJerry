(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();

    
      $('.carousel').carousel();
      $(".dropdown-button").dropdown();
        

  }); // end of document ready
})(jQuery); // end of jQuery name space